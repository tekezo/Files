Orzレイアウト

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ver 2.0----------------------------------------
20141031


### Version 2.0

バージョン表記を改め、Version 2.0として公開します。

### コマンドキー周りを大きく改善

コマンドキーやオブションキーとの組み合わせで、右手のキー配列がずれていなかった組み合わせを修正しました。

どのキーもorzレイアウトで動作するようになりました。Photoshopやイラストレーターなどのショットカットに対応しました。

### ATOKの単語登録ショートカット

従来のバージョンの場合、特定の環境下では、ATOKの単語登録ショートカットが動作しないトラブルがあり、改善しました。

### Sublime Text 2のショートカット

Package Controlを起動するショートカット『cmd+shift+P』を動作するように修正しました。


### 動作がおかしい時は旧バージョンを

定義ファイルを大きく書き換えました。繰り返しテストしておりますが、万が一、アップデートしたことで不安定になった場合は、下の旧バージョンに戻してください。

旧バージョン OrzレイアウトVer.170  → http://www.monochrome-photo.info/?p=17408

よろしくお願いします。


Ver 0.170----------------------------------------
20130927

KeyRemap4MacBook 8.4.0 アップデートにて、発生したorzレイアウト内のバグを修正。

1,orz_combination.xml

下記 <identifier>がトラブル原因 ＿定義ミス＿ のため コメントアウト

<name>カーソルキー PNBF and Control+AE with Orz</name>
            コメントアウト＞＞ <!-- <identifier>remap.orz_cursol_support</identifier> 20130927 del-->
            <include path="orz_cursor.xml" />


2,orz_cursor.xml

2箇所 <identifier>を追記

<name>Control+PNBF to Up/Down/Left/Right</name>
      追記 ＞＞ <identifier>Control_PNBF2Up_Down_Left_Right</identifier>
      <not>{{EMACS_MODE_IGNORE_APPS}}</not>

<name>Control+AE to Command+Left/Right</name>
      追記 ＞＞ <identifier>Control_AE2Command_Left_Righ</identifier>
      <not>{{EMACS_MODE_IGNORE_APPS}}</not>


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ver 0.162----------------------------------------
201307009

Evernote に対応するため
    Command + shift + i
    Command + shift + o

orz_command.xml 以下のコードを追加


        <name>Command + shift + i	evernote</name>
        <autogen>__KeyToKey__ KeyCode::O ,ModifierFlag::COMMAND_L  , ModifierFlag::SHIFT_L, KeyCode::I ,ModifierFlag::COMMAND_L , ModifierFlag::SHIFT_L </autogen>
        <autogen>__KeyToKey__ KeyCode::O ,ModifierFlag::COMMAND_R  , ModifierFlag::SHIFT_L, KeyCode::I ,ModifierFlag::COMMAND_R , ModifierFlag::SHIFT_L</autogen>
        
                <name>Command + shift + o	evernote</name>
        <autogen>__KeyToKey__ KeyCode::P ,ModifierFlag::COMMAND_L  , ModifierFlag::SHIFT_L, KeyCode::O ,ModifierFlag::COMMAND_L , ModifierFlag::SHIFT_L </autogen>
        <autogen>__KeyToKey__ KeyCode::P ,ModifierFlag::COMMAND_R  , ModifierFlag::SHIFT_L, KeyCode::O ,ModifierFlag::COMMAND_R , ModifierFlag::SHIFT_L</autogen>   



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ver 0.16----------------------------------------
20130326

orz_base.xml
左右シフトキーの設定を5つ追加

	左シフト＝英数, 右シフト＝スペース
	左シフト＝英数, 右シフト＝かな
	左シフト＝スペース, 右シフト＝右コマンド
	左シフト＝左コマンド, 右シフト＝スペース
	左シフト＝左コマンド, 右シフト＝右コマンド

「EISUU x2 to EISUU」のメニューを表示
orz_kotoeri.xml
	control+ .to「、」の表記ミスを修正


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ver 0.15----------------------------------------


20130325

orz_command.xml
	
	firefox対応
    	command+6,7,8,9 for book mark of safari 
    
    	command+ 0,+,- for view of safari 
    	ただし  + キー入力のshiftは左のみ対応 
    
    環境設定呼び出し追加
    	Command + ,  で環境設定
    	
------------------------------------------------
    

firefox対応
    command+6,7,8,9 for book mark of safari 
    command+ 0,+,- for view of safari 
    	ただし  + キー入力のshiftは左のみ対応 
    
    環境設定呼び出し追加
    	Command + ,  で環境設定

   
