#ifndef IOLOGWRAPPER_HPP
#define IOLOGWRAPPER_HPP

#define IOLOG_DEBUG(...)
#define IOLOG_DEBUG_POINTING(...)
#define IOLOG_DEVEL(...)
#define IOLOG_ERROR(...)
#define IOLOG_INFO(...)
#define IOLOG_WARN(...)

#endif
