// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

// ------------------------------------------------------------
// NSDistributedNotificationCenter for EventViewer.app, AXNotifier.app, multitouchextension.app.
#define kKarabinerServerDidLaunchNotification @"org.pqrs.Karabiner.notification.serverDidLaunch"

// ------------------------------------------------------------
// NSConnection
#define kKarabinerConnectionName @"org.pqrs.Karabiner.server"
