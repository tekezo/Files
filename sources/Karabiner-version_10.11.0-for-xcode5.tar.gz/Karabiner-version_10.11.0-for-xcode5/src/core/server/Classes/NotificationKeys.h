// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

#define kConfigXMLReloadedNotification @"ConfigXMLReloaded"
#define kConfigListChangedNotification @"ConfigListChanged"
#define kPreferencesChangedNotification @"PreferencesChanged"
#define kStatusWindowPreferencesOpenedNotification @"StatusWindowPreferencesOpenedNotification"
#define kStatusWindowPreferencesClosedNotification @"StatusWindowPreferencesClosedNotification"
