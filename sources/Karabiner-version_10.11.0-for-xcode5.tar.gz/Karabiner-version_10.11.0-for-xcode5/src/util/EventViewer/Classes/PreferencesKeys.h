// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

#define kForceStayTop @"kForceStayTop"
#define kShowInAllSpaces @"kShowInAllSpaces"
#define kHideIgnorableEvents @"kHideIgnorableEvents"
