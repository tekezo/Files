// -*- Mode: objc -*-

#import <Cocoa/Cocoa.h>

@interface TabView : NSTabView

@end
