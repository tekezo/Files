// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

#define kFocusedUIElementChanged @"kFocusedUIElementChanged"
#define kWindowVisibilityChanged @"kWindowVisibilityChanged"
