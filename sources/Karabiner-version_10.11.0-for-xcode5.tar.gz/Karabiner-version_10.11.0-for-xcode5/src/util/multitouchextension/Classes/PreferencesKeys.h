// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

#define kDelayBeforeTurnOff @"kDelayBeforeTurnOff"
#define kDelayBeforeTurnOn @"kDelayBeforeTurnOn"
